<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
    $middleware->alias([
        'has.business' => \App\Http\Middleware\EnsureBusinessExists::class,
        'is.owner' => \App\Http\Middleware\EnsureIsOwner::class,
        'not.staff' => \App\Http\Middleware\EnsureNotStaff::class,
        'is.super_admin' => \App\Http\Middleware\EnsureSuperAdmin::class,
        'subscription.active' => \App\Http\Middleware\EnsureSubscriptionActive::class,
        'email.verified' => \App\Http\Middleware\EnsureEmailVerified::class,
    ]);
   })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
