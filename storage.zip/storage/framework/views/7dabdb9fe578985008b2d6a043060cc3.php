<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family: Arial, sans-serif; color: #1a1a1a; line-height: 1.5;">
    <p>Hi <?php echo e($sale->customer->name ?? 'there'); ?>,</p>

    <p>
        Thanks for shopping with <strong><?php echo e($sale->business->name); ?></strong>.
        Your receipt for invoice <strong><?php echo e($sale->invoice_number); ?></strong>
        (total <?php echo e($sale->business->currency_symbol); ?><?php echo e(number_format($sale->total, 2)); ?>)
        is attached as a PDF.
    </p>

    <?php if($sale->business->setting?->receipt_footer): ?>
        <p style="color: #555; font-size: 13px;"><?php echo e($sale->business->setting->receipt_footer); ?></p>
    <?php endif; ?>

    <p>— <?php echo e($sale->business->name); ?></p>
</body>
</html>
<?php /**PATH C:\Users\JIFFYE 3\Desktop\ledgerly-backend\resources\views/emails/receipt.blade.php ENDPATH**/ ?>